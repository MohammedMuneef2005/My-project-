import hero_illustrator from './hero_illustration.svg';
import wave_vector from './wave_vector.svg';

export { hero_illustrator, wave_vector };
