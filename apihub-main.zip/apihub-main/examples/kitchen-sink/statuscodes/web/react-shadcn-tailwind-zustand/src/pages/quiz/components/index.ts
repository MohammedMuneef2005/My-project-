import QuestionsCard from "./QuestionsCard";
export { QuestionsCard };
