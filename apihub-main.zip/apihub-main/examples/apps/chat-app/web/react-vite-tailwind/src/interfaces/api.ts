export interface FreeAPISuccessResponseInterface {
  data: any;
  message: string;
  statusCode: number;
  success: boolean;
}
