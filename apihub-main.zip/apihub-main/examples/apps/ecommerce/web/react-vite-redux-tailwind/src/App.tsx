import RoutePaths from "./RoutePaths";

function App() {
  return <RoutePaths />;
}

export default App;
