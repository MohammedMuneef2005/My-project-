import PageNotFoundPage from "../presentation/PageNotFoundPage";

const PageNotFoundPageContainer = () => {
  return <PageNotFoundPage />;
};

export default PageNotFoundPageContainer;
